//[BEGIN:AUTHENTICATION]
import { Context, Controller, Method, Middleware, Route } from '@apollosoftwarexyz/cinnamon';
import { MaybeAuthenticated } from '../middlewares/Authentication';
//[END:AUTHENTICATION]
//[BEGIN:!AUTHENTICATION]
import { Context, Controller, Method, Route } from '@apollosoftwarexyz/cinnamon';
//[END:!AUTHENTICATION]

@Controller()
export default class IndexController {

    /**
//[BEGIN:AUTHENTICATION]
     * Greets the user.
     * If they are authenticated, they will be greeted by name.
//[END:AUTHENTICATION]
//[BEGIN:!AUTHENTICATION]
     * Greets the world.
//[END:!AUTHENTICATION]
     */
//[BEGIN:AUTHENTICATION]
    @Middleware(MaybeAuthenticated)
//[END:AUTHENTICATION]
    @Route(Method.GET, '/')
    public async index(ctx: Context) {
//[BEGIN:AUTHENTICATION]
//[BEGIN:ASL_PROTOCOL]
        return `Hello, ${ctx.user?.smartName ?? 'Guest'}!`;
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.body = `Hello, ${ctx.user?.smartName ?? 'Guest'}!`;
//[END:!ASL_PROTOCOL]
//[END:AUTHENTICATION]
//[BEGIN:!AUTHENTICATION]
//[BEGIN:ASL_PROTOCOL]
        return 'Hello, world!';
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.body = 'Hello, world!';
//[END:!ASL_PROTOCOL]
//[END:!AUTHENTICATION]
    }

}
