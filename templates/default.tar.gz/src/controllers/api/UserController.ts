//IF:AUTHENTICATION
import { Body, Context, Controller, Method, Middleware, Route } from '@apollosoftwarexyz/cinnamon';
import * as argon2 from 'argon2';

import { OnlyAuthenticated } from '../../middlewares/Authentication';
//[BEGIN:VALIDATOR]
import { ValidateBody } from '../../utils/validation';
import { UserDeleteRequestSchema, UserSetAvatarSchema } from '../../schema/requests/user';
//[END:VALIDATOR]
//[BEGIN:ASL_ERRORS]
import { AppError, toAppError } from '../../schema/errors';
//[END:ASL_ERRORS]
//[BEGIN:AVATAR]
import { Asset, decodeBase64Asset } from '../../models/Asset';
//[END:AVATAR]

/**
 * User controller.
 *
 * This controller contains the logic necessary to manage users (e.g., update
 * profile information, destroy account, etc.)
 */
@Controller('api', 'user')
export default class UserController {

//[BEGIN:AVATAR]
    /**
     * Update the user's profile picture (avatar).
     *
     * This endpoint accepts a base64-encoded image payload, which is then
     * decoded and stored in the database.
     */
//[BEGIN:VALIDATOR]
    @Middleware(ValidateBody(UserSetAvatarSchema))
//[END:VALIDATOR]
    @Middleware(Body({
        options: {
            limit: '16mb'
        }
    }))
    @Middleware(OnlyAuthenticated)
    @Route(Method.POST, '/avatar')
    public async setAvatar(ctx: Context) {
        const em = ctx.getEntityManager();

        const { avatar } = ctx.request.body;

        // Attempt to decode the base64 image payload.
        let data;
        try {
            data = await decodeBase64Asset(ctx, avatar);
        } catch (ex) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.invalidRequestBody,
                'The provided image is invalid.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(400, "ERR_INVALID_IMAGE", "The provided image is invalid.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 400;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'The provided image is invalid.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        // Create a new asset for the user's profile picture.
        const asset = new Asset({
            mimeType: data.mimeType,
            payload: data.imageData,
            owner: ctx.user!
        });

        // Persist the asset to the database, and update the asset's name to
        // include the ID and extension, then persist again.
        await em.persistAndFlush(asset);
        asset.name = `${asset.id}.${data.extension}`;
        await em.persistAndFlush(asset);

        // Update the user's profile picture.
        ctx.user!.avatar = `/api/asset/v1/${asset.type}/${asset.id}`;
        await em.persistAndFlush(ctx.user!);

        // Delete any old profile pictures, now that the new one has been set.
        await em.nativeDelete(Asset, {
            id: { $ne: asset.id },
        });

//[BEGIN:ASL_PROTOCOL]
        return ctx.success({
            message: 'Your profile picture has been updated.'
        });
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = 'text/plain';
        ctx.response.body = 'Your profile picture has been updated.';
        return;
//[END:!ASL_PROTOCOL]
    }
//[END:AVATAR]

    /**
     * Delete the user's account.
     *
     * This endpoint requires the user to provide their password, to prevent
     * accidental deletion. The account is then deleted.
     *
     * The user is implicitly logged out because the sessions and any other
     * user-owned assets are cascade-deleted.
     */
//[BEGIN:VALIDATOR]
    @Middleware(ValidateBody(UserDeleteRequestSchema))
//[END:VALIDATOR]
    @Middleware(Body())
    @Middleware(OnlyAuthenticated)
    @Route(Method.DELETE, '/delete')
    public async delete(ctx: Context) {

        const { password } = ctx.request.body;

        // Validate the password.
        if (!await argon2.verify(ctx.user!.password, password)) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.unauthorized,
                'You did not provide the correct password.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(401, "ERR_UNAUTHORIZED", "You did not provide the correct password.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 401;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'You did not provide the correct password.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        // Delete the user.
        await ctx.getEntityManager().removeAndFlush(ctx.user!);
//[BEGIN:ASL_PROTOCOL]
        return ctx.success({
            message: 'You have been logged out and your account has been deleted.'
        });
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = 'text/plain';
        ctx.response.body = 'You have been logged out and your account has been deleted.';
        return;
//[END:!ASL_PROTOCOL]

    }


}
