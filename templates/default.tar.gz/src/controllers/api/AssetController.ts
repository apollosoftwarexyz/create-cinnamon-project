//IF:ASSET
import { Context, Controller, Method, Route } from '@apollosoftwarexyz/cinnamon';
import { Asset } from '../../models/Asset';
//[BEGIN:ASL_ERRORS]
import { AppError, toAppError } from '../../schema/errors';
//[END:ASL_ERRORS]

/**
 * Asset controller.
 *
 * This controller contains the logic necessary to retrieve assets from the
 * database.
 */
@Controller('api', 'asset', 'v1')
export default class AssetController {

    @Route(Method.GET, '/:type/:id')
    public async getAsset(ctx: Context) {
        const { type, id } = ctx.params;

        const asset = await ctx.getEntityManager().findOne(Asset, {
            id,
            type
        });

        if (!asset) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.missingEntity,
                'The requested asset could not be found.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(404, "ERR_MISSING_ENTITY", 'The requested asset could not be found.');
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 404;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'The requested asset could not be found.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        ctx.response.set('Cache-Control', 'public, max-age=15552000');
//[BEGIN:ASL_PROTOCOL]
        return ctx.successRaw(asset.payload, asset.mimeType);
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = asset.mimeType;
        ctx.response.body = asset.payload;
        return;
//[END:!ASL_PROTOCOL]
    }

}
