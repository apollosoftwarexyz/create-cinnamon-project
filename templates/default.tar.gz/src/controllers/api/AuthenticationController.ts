//IF:AUTHENTICATION
import { Body, Context, Controller, Method, Middleware, Route } from '@apollosoftwarexyz/cinnamon';

import * as argon2 from 'argon2';
import { shuffleHashingOptions } from '../../utils/security';

import { OnlyAuthenticated } from '../../middlewares/Authentication';

//[BEGIN:VALIDATOR]
import { ValidateBody } from '../../utils/validation';
import { CreateAccountRequestSchema, LoginRequestSchema } from '../../schema/requests/authentication';
//[END:VALIDATOR]

import { User } from '../../models/User';
import { Session } from '../../models/Session';
import { expr, wrap } from '@mikro-orm/core';

//[BEGIN:ASL_ERRORS]
import { AppError, toAppError } from '../../schema/errors';
//[END:ASL_ERRORS]

/**
 * Public-facing user authentication controller.
 *
 * This contains the logic necessary to create and (de-)authenticate users.
 */
@Controller('api', '_auth')
export default class AuthenticationController {

    /**
     * Log an existing user in.
     *
     * This endpoint accepts a username (or email) and password, and returns a
     * session token that can be used to authenticate future requests.
     *
     * The username field is automatically checked against both the username and
     * email fields in the database, so users can log in with either.
     */
//[BEGIN:VALIDATOR]
    @Middleware(ValidateBody(LoginRequestSchema))
//[END:VALIDATOR]
    @Middleware(Body())
    @Route(Method.POST, 'login')
    public async login(ctx: Context) {
//[BEGIN:VALIDATOR]
        // Destructure request body. It's already been validated, so this is safe to do.
//[END:VALIDATOR]
//[BEGIN:!VALIDATOR]
        // TODO: Validate the request body.
//[END:!VALIDATOR]
        const { username, password, pushToken } = ctx.request.body;

        // Attempt to find the user in the database.
        const user = await ctx.getEntityManager().findOne(User, {
            $or: [
                { [expr('lower(username)')]: username },
                { [expr('lower(email)')]: username }
            ]
        });

        // If no user was found, return an error.
        if (!user) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.unauthenticated,
                'Invalid username or password.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(401, "ERR_UNAUTHENTICATED", "Invalid username or password.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 401;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'Invalid username or password.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        // Verify the password.
        try {
            if (!await argon2.verify(user.password, password, shuffleHashingOptions)) {
//[BEGIN:ASL_ERRORS]
                return toAppError(
                    ctx,
                    AppError.unauthenticated,
                    'Invalid username or password.'
                );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
                return ctx.error(401, "ERR_UNAUTHENTICATED", "Invalid username or password.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
                ctx.response.status = 401;
                ctx.response.headers['content-type'] = 'text/plain';
                ctx.response.body = 'Invalid username or password.';
                return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
            }
        } catch (ex) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.unexpected,
                'An unexpected problem occurred whilst checking your password. If the issue persists, please get in touch.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(500, "ERR_UNEXPECTED", "An unexpected problem occurred whilst checking your password. If the issue persists, please get in touch.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 500;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'An unexpected problem occurred whilst checking your password. If the issue persists, please get in touch.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        // Finally, all checks were valid so create a new session and return it.
        const session = await AuthenticationController.startSession(ctx, {
            user,
//[BEGIN:PUSH_TOKENS]
            pushToken
//[END:PUSH_TOKENS]
        });

//[BEGIN:ASL_PROTOCOL]
        return ctx.success({
            user: wrap(user),
            requestToken: session.requestToken,
            message: 'You have been logged in successfully!'
        });
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = 'application/json';
        ctx.response.body = JSON.stringify({
            user: wrap(user),
            requestToken: session.requestToken,
            message: 'You have been logged in successfully!'
        });
        return;
//[END:!ASL_PROTOCOL]
    }

    /**
     * Create a new user account.
     *
     * Users who are new to the application can create an account using this
     * endpoint. The request body must contain the user's email and username.
     * The password is also required, and is hashed immediately before being
     * stored in the database using Argon2.
     *
     * The user is automatically logged in after their account is created and a
     * session token is returned.
     */
//[BEGIN:VALIDATOR]
    @Middleware(ValidateBody(CreateAccountRequestSchema))
//[END:VALIDATOR]
    @Middleware(Body())
    @Route(Method.POST, 'register')
    public async register(ctx: Context) {
//[BEGIN:VALIDATOR]
        // Destructure request body. It's already been validated, so this is safe to do.
//[END:VALIDATOR]
//[BEGIN:!VALIDATOR]
        // TODO: Validate the request body.
//[END:!VALIDATOR]
        const {
            user: {
                email,
                username,
            },
            password,
            pushToken
        } = ctx.request.body;

        // Create the user in the database.
        const userRepo = ctx.getEntityManager().getRepository(User);

        if ((await userRepo.count({ $or: [ { [expr('lower(username)')]: username.toLowerCase() }, { [expr('lower(email)')]: email.toLowerCase() } ] })) > 0) {
//[BEGIN:ASL_ERRORS]
            return toAppError(
                ctx,
                AppError.conflictingEntity,
                'A user with that username or email already exists.'
            );
//[END:ASL_ERRORS]
//[BEGIN:!ASL_ERRORS]
//[BEGIN:ASL_PROTOCOL]
            return ctx.error(409, "ERR_CONFLICT", "A user with that username or email already exists.");
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
            ctx.response.status = 409;
            ctx.response.headers['content-type'] = 'text/plain';
            ctx.response.body = 'A user with that username or email already exists.';
            return;
//[END:!ASL_PROTOCOL]
//[END:!ASL_ERRORS]
        }

        // Create and persist the user.
        const user = new User({
            username,
            email,
            passwordHash: await argon2.hash(password, shuffleHashingOptions),
        });
        await ctx.getEntityManager().persistAndFlush(user);

        const session = await AuthenticationController.startSession(ctx, {
            user,
//[BEGIN:PUSH_TOKENS]
            pushToken
//[END:PUSH_TOKENS]
        });

        // Now, return the user and session to the client.
//[BEGIN:ASL_PROTOCOL]
        return ctx.success({
            user: wrap(user),
            requestToken: session.requestToken,
            message: 'Your account has been created successfully!'
        });
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = 'application/json';
        ctx.response.body = JSON.stringify({
            user: wrap(user),
            requestToken: session.requestToken,
            message: 'Your account has been created successfully!'
        });
        return;
//[END:!ASL_PROTOCOL]
    }

    /**
     * Log the user out.
     *
     * Destroys an active session, logging the user out.
     */
    @Middleware(OnlyAuthenticated)
    @Route(Method.POST, '/logout')
    public async logout(ctx: Context) {
        await ctx.getEntityManager().removeAndFlush(ctx.session!);
//[BEGIN:ASL_PROTOCOL]
        return ctx.success({ message: 'You have been logged out successfully.' });
//[END:ASL_PROTOCOL]
//[BEGIN:!ASL_PROTOCOL]
        ctx.response.headers['content-type'] = 'text/plain';
        ctx.response.body = 'You have been logged out successfully.';
        return;
//[END:!ASL_PROTOCOL]
    }

    private static async startSession(ctx: Context, sessionParams: {
        user: User;
//[BEGIN:PUSH_TOKENS]
        pushToken: string;
//[END:PUSH_TOKENS]
    }): Promise<Session> {
        const ipAddress = (ctx.headers['cf-connecting-ip'] as string) ?? ctx.ip;

        // Create (but do not persist yet) a session object for the user.
        const session = new Session({
            user: sessionParams.user,
//[BEGIN:PUSH_TOKENS]
            pushToken: sessionParams.pushToken,
//[END:PUSH_TOKENS]
            ipAddress,
        });

        // Delete any existing sessions for the user.
        await ctx.getEntityManager().nativeDelete(Session, { user: sessionParams.user });

        // Persist the session and return it.
        await ctx.getEntityManager().persistAndFlush(session);
        return session;
    }

}
