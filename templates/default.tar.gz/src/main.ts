import Cinnamon from '@apollosoftwarexyz/cinnamon';
//[BEGIN:ASL_PROTOCOL]
import { ApolloProtocol } from '@apollosoftwarexyz/cinnamon-plugin-asl-protocol';
//[END:ASL_PROTOCOL]
//[BEGIN:WEBSERVER_SETTINGS_PLUGIN]
import WebServerSettingsPlugin from './plugins/WebServerSettingsPlugin';
//[END:WEBSERVER_SETTINGS_PLUGIN]

(async () => {
    await Cinnamon.initialize({
        async load(framework) {
//[BEGIN:ASL_PROTOCOL]
            // Apollo Protocol for API responses.
            framework.use(new ApolloProtocol(framework));
//[END:ASL_PROTOCOL]

//[BEGIN:WEBSERVER_SETTINGS_PLUGIN]
            // Web Server Settings plugin.
            framework.use(new WebServerSettingsPlugin(framework));
//[END:WEBSERVER_SETTINGS_PLUGIN]
        }
    });
})();
